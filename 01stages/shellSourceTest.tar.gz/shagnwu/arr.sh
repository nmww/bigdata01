#!/bin/bash
arr=(v1 v2 v3 v4 v5)
echo ${arr[0]}
echo after change arr[0]
arr[0]=v0
echo ${arr[0]}
echo after change arr[100] no continue index
arr[100]=v100
echo ${arr[90]}
echo ${arr[100]}
echo 获取数组长度 '${#arr[@]}'
echo ${#arr[@]}
echo 获取当前元素值的长度'${#arr[100]}'
echo ${#arr[100]}
echo 输出数组的所有元素'${arr[@]}'
echo ${arr[@]}
echo 输出数组的所有元素'${arr[*]}'
echo ${arr[*]}
:<< abc
abc 是自定义  
在abc之间的是多行注释
':<<' 是固定的开始
abc
echo for 显示arr
for i in ${arr[@]} ;do
 echo $i ; done
