#!/bin/bash
your_name="qinjx"
echo $your_name
echo ${your_name}
myUrl="www.baidu.com"
echo $myUrl ===================
unset myUrl
echo ${myUrl} -------------------



