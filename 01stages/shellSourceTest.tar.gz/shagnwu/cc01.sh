#!/bin/bash
echo " ===\"====double yinhao " 
your_name="huagong"
g="hello1 , "$your_name" ! "
g1="hello2 , ${your_name}"
echo $g $g1
echo " ===\'====double yinhao " 
your_name="danyinhao"
g='dan hello1 , '$your_name' ! '
g1='dan can not show \${name} hello2 , ${your_name}'
echo $g $g1
echo ======test=========
g='dan hello1 , "$your_name" ! '
echo g
g1='dan hello1 , $your_name ! '
echo g1
