!#/bin/bash
your_name=abc
greeting="hello, "$your_name" !"
greeting1="hello, ${your_name} !"
echo $greeting
echo $greeting1
