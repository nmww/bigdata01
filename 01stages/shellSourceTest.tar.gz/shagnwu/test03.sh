#!/bin/bash
# ls /etc show name  set to file 
for file in `ls /etc` ; do
   echo "local file name is : ${file}"
done
