!#/bin/bash
a=zhangsan
#==========单引号定义
name1='abc + $a'
name2='abc + ${a}'
echo =\'==\$a==\$\{a\}===\'====
echo name1 name2
#==========单引号 包含单引号
name3='abc + '$a''
name4='abc + '${a}''
echo =\'=\'=\$a==\$\{a\}=\'==\'====
echo name3 name4
#==========
