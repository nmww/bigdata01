#~/bin/bash
str=abcdefshk
echo str = $str
echo lenth is : ${#str}
echo substring 1-3: ${str:1:3}
