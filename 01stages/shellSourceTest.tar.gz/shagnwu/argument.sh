#!/bin/bash
echo ==显示第一个参数  '$1'
echo 第一个参数是:$1
echo ==显示所有参数  '$@'
echo 所有参数是：$@
echo ==单一字符串返回所有参数  '$*'
echo 单一字符串获得所有参数是：$*
echo ==脚本运行的当前进程ID号:'$$'
echo 脚本运行的当前进程ID号: $$
echo ==后台运行的最后一个进程的ID号:'$!'
echo 后台运行的最后一个进程的ID号:$!
echo ==双引号中 '$@ 和 $*的区别'
echo "双引号中 \$*" 
for i in "$*" ;do
	echo $i ;done
echo "双引号中 \$@" 
for i in "$@" ;do
	echo $i ;done
