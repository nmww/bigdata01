!#/bin/bash
echo "this is a string"
a=123456
echo '$a single pring yuan'
b="nihao \n"
echo -e $b


