#!/bin/bash
echo "Hello Shell!"
for i in 123456
do
   echo $i======
done
