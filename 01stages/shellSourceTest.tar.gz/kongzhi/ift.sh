#!/bin/bash
# 注意：if 的后边一定要有 空格
# 注意：[  ]  符号的左右要有 空格
if [ $(ps -ef | grep -c "ssh") -gt 1 ]
# -gt  是判断是否大于的意思 ＞
then
  echo "true"
fi
