#!/bin/bash
a=1
while [ $a -lt 20 ]
 do
  echo $a
  # ` ` 命令引入 需要包含等号右侧加法
  a=`expr $a + 1` 
 done
