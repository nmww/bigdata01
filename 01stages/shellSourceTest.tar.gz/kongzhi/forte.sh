#!/bin/bash
# 注:每行一条语句，如果多条需要分号 ; 分割
for loop in 1 2 3 4 5
do
 echo $loop # 循环输出每个值
done
