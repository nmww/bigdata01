#!/bin/bash

# 1.获取到所有文件
# 2.判断是文件or文件夹
# 3.判断每个文件是否有 .sh扩展名
# 4.没有.sh的 file 进行添加
for name in `ls ./`
 do
  if [ -f $name ]
   then
    fileLen=${#name}
    kzName=${name:fileLen-3:fileLen}
    #echo $kzName
    if [ $kzName == '.sh' ]
     then
      echo 当前的文件名称是：$name
    else
      mv ${name} ${name}.sh
    fi
  fi
 done


