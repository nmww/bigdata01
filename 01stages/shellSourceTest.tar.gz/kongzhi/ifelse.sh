#!/bin/bash
a=10
b=20
# 注：== 符号左右要有空格
if [ $a == $b ]
 then 
  echo "a 等于 b"
elif [ $a -gt $b ] # -gt 大于
 then
  echo "a 大于 b"
elif [ $a -lt $b ] # -lt 小于
 then
  echo "a 小于 b"
else # 里边没有then
  echo "nothing"
fi # if语句的结束标志
