#!/bin/bash
# 判断输入的 名称 是一个 文件 还是一个 文件夹
if [ -f $1 ]
  then 
   echo file =  $1
  elif [ -d $1 ]
   then
    echo dir =  $1 
  else
    echo ' $1 nothing ' = $1
fi

