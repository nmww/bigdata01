#!/bin/bash
num1=$[2*3]
num2=$[1+5]
echo num1 = ${num1}
echo num2 = ${num2}
# if 判断两个表达式是否相等  -eq
if test ${num1} -eq ${num2}
 then
  echo "两个表达式相等"
else
  echo "不相等"
fi
