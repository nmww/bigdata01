#!/bin/bash
while :
do
 echo -n " ======= input : "
 read 

done
