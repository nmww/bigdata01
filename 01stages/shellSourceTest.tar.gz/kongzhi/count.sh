#!/bin/bash
# 无限循环语法格式 while 后边有  冒号 :
while :
 do
  echo -n "输入1-5数字："
  read aNum
  case $aNum in
   [1-5]) echo  aNum  =  $aNum ;; 
   "x") echo 'x quit'
     break;;
   *) echo "your input out of 1-5!!!!!"
     continue ;;
  esac
done
