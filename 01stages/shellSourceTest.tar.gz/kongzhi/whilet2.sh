#!/bin/bash
a=1
while [ $a -lt 20 ]
 do
  echo $a
  # ` ` 命令引入 需要包含等号右侧加法
  a=`expr $a + 1` 
 done
echo ==============
b=1
# until 不满足条件执行
until [ $b -ge 20 ]   # -ge 大于等于
 do
  echo $b
  # ` ` 命令引入 需要包含等号右侧加法
  b=`expr $b + 1` 
 done
