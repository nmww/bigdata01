#!/bin/bash
while :
 do
  echo -n "输入1-5之间的数字:"
  read aNume  # 读取控制台输入，赋值给变量
  case $aNume in
    1|2|3|4|5) echo "你输入的数字是：" $aNume;;
    *) echo "输入的数字无效" 
       break ;;
  esac
 done
