#!/bin/bash
echo "输入1-4之间的额数字:"
ehco "输入的数字为："
# 分支语句 case
# read 从控制台读取输入的内容
read aNum
case $aNum in 
 # 每个case都需要两个分号结束
 1) echo "你输入了 1" ;;
 2) echo "你输入了 2" ;;
 3) echo "你输入了 3" ;;
 4) echo "你输入了 4" ;;
 5) echo "你输入了 5" ;;
 *) echo "defalut 你输入的不是有效数字" ;;
esac #case 反过来写作为结束标识
