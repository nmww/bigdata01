#!/bin/bash
# 判断本地文件扩展名，将 .sh 的扩展名都去掉
for file in `ls ./`
 do
  #prefix=${file:`expr ${#file} - 3`}  
  l=`expr ${#file} - 3` # 得到文件的长度，不包含扩展名
  k=${file:l:l+3}   # 得到扩展名部分  .扩展名
  #echo $k          # 打印所有扩展名
  if [ $k == '.sh' ] # 判断扩展名是否 是  .sh
   then
    newName=${file:0:l}  # 得到去掉扩展名后的名称
    mv ${file} ${newName} # 修改文件名 为新的没有扩展名的名称
    #echo $newName
  fi  # 结束 if
 done # 结束 for
